//
//  ReceptiApp.swift
//  Recepti
//
//  Created by MacLab6 on 22.10.22..
//

import SwiftUI

@main
struct ReceptiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
